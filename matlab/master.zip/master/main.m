%begin from the first UI
addpath(genpath('generateImage'));
addpath(genpath('output'));
addpath(genpath('UI'));
addpath(genpath('utils'));
GUI1;